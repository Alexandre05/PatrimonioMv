package Atividades;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import com.google.gson.Gson;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import Adapter.AdapterAnuncios;
import Helper.ConFirebase;
import Mode.ItensVistorias;
import br.com.patrimoniomv.R;
import android.graphics.pdf.PdfDocument;

import net.glxn.qrgen.android.QRCode;

public class Relatorios extends AppCompatActivity {
    private EditText editTextLocation;
    private Button buttonSearch,btn_imprimir;
    private List<ItensVistorias> currentSearchResults = new ArrayList<>();

    private RecyclerView recyclerView;
    private List<ItensVistorias> anuncios = new ArrayList<>();
    private AdapterAnuncios adapterAnuncios;
    private DatabaseReference anunciosRef;
    private FirebaseUser currentUser;
    private EditText editTextLicensePlate;
    private RadioGroup radioGroupSearchCriteria;
    private RadioButton radioButtonLocation;
    private RadioButton radioButtonLicensePlate;
    private ItensVistorias selectedItem;
    private Button buttonGeneratePdf,buttonGenerateQrCode;
    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 11;
    private static final int REQUEST_WRITE_STORAGE = 112;
    private static final int STORAGE_PERMISSION_CODE = 101;
    private static final int CREATE_FILE_REQUEST = 1;
    private static final int REQUEST_CODE_SCAN_QR_CODE = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relatorios);
        editTextLicensePlate = findViewById(R.id.editText_licensePlate);
        radioGroupSearchCriteria = findViewById(R.id.radioGroup_searchCriteria);
        radioButtonLocation = findViewById(R.id.radioButton_location);
        editTextLocation = findViewById(R.id.editText_location);
        radioButtonLicensePlate = findViewById(R.id.radioButton_licensePlate);
        recyclerView = findViewById(R.id.recyclerView_results);
        buttonSearch = findViewById(R.id.button_search);
        buttonGenerateQrCode = findViewById(R.id.buttonGenerateQrCode);
        anunciosRef = ConFirebase.getFirebaseDatabase().child("vistoriasConcluidas");
        Log.d("FIREBASE_STRUCTURE", "anunciosRef: " + anunciosRef);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        adapterAnuncios = new AdapterAnuncios(anuncios, this);
        recyclerView.setAdapter(adapterAnuncios);

        editTextLocation.setVisibility(View.GONE);
        radioButtonLicensePlate.setChecked(true);
        currentUser = FirebaseAuth.getInstance().getCurrentUser();

        radioGroupSearchCriteria.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.radioButton_location) {
                    editTextLocation.setVisibility(View.VISIBLE);
                    editTextLicensePlate.setVisibility(View.GONE);
                } else if (i == R.id.radioButton_licensePlate) {
                    editTextLocation.setVisibility(View.GONE);
                    editTextLicensePlate.setVisibility(View.VISIBLE);
                }
            }
        });
        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RadioGroup radioGroup = findViewById(R.id.radioGroup_searchCriteria);
                int selectedId = radioGroup.getCheckedRadioButtonId();

                SearchCallback searchCallback = new SearchCallback() {
                    @Override
                    public void onSearchCompleted(List<ItensVistorias> searchResults) {
                        currentSearchResults.clear();
                        currentSearchResults.addAll(searchResults);
                        Log.d("SearchResults", "Tamanho da lista: " + currentSearchResults.size());
                    }
                };

                if (selectedId == R.id.radioButton_location) {
                    String location = editTextLocation.getText().toString().trim().toUpperCase();
                    if (!location.isEmpty()) {
                        searchByCategory(location, searchCallback);
                    } else {
                        Toast.makeText(Relatorios.this, "Digite a localização", Toast.LENGTH_SHORT).show();
                    }
                } else if (selectedId == R.id.radioButton_licensePlate) {
                    String licensePlate = editTextLicensePlate.getText().toString().trim().toUpperCase();
                    if (!licensePlate.isEmpty()) {
                        searchByLicensePlate(licensePlate, searchCallback);
                    } else {
                        Toast.makeText(Relatorios.this, "Digite o número da placa", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });



        buttonGenerateQrCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!currentSearchResults.isEmpty()) {
                    String searchResultsData = itemListToJson(currentSearchResults);

                    // Gere o QR Code com as informações dos resultados da pesquisa
                    Bitmap qrCodeBitmap = generateQRCode(searchResultsData);

                    Log.d("QRCode", "Generated QR Code bitmap: " + qrCodeBitmap);

                    // Verifique a permissão de armazenamento
                    if (ContextCompat.checkSelfPermission(Relatorios.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                        // Salve o QR Code no dispositivo
                        String filePath = saveQRCodeToStorage(qrCodeBitmap);

                        Log.d("QRCode", "Saved QR Code to file path: " + filePath);

                        // Compartilhe o QR Code
                        showQRCodeDialog(qrCodeBitmap);
                    } else {
                        // Solicite a permissão de armazenamento
                        ActivityCompat.requestPermissions(Relatorios.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                    }
                } else {
                    Toast.makeText(Relatorios.this, "Realize uma pesquisa primeiro", Toast.LENGTH_SHORT).show();
                }
            }
        });


        buttonGeneratePdf = findViewById(R.id.button_generate_pdf);

        buttonGeneratePdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Exemplo de datas de início e término para filtrar os anúncios
                String startDate = "01/01/2023";
                String endDate = "31/12/2023";

                List<ItensVistorias> filteredAnuncios = filterByDate(anuncios, startDate, endDate);
                if (checkStoragePermission()) {
                    createPdf(filteredAnuncios);
                    checkWriteStoragePermission();
                } else {
                    requestStoragePermission();

                }
            }
        });
    }
    public List<ItensVistorias> filterByInspectorDate(List<ItensVistorias> anuncios, String inspectorId, String startDate, String endDate) {
        List<ItensVistorias> filteredAnuncios = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        try {
            Date start = dateFormat.parse(startDate);
            Date end = dateFormat.parse(endDate);

            for (ItensVistorias anuncio : anuncios) {
                Date anuncioDate = dateFormat.parse(anuncio.getData());

                if (anuncio.getNomePerfilU().equals(inspectorId) &&
                        (anuncioDate.equals(start) || anuncioDate.after(start)) &&
                        (anuncioDate.equals(end) || anuncioDate.before(end))) {
                    filteredAnuncios.add(anuncio);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao filtrar por data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return filteredAnuncios;
    }
    private String itemListToJson(List<ItensVistorias> itemList) {
        Gson gson = new Gson();
        String json = gson.toJson(itemList);
        json = json.replace("\\u003d", "=").replace("\\u0026", "&");
        return json;
    }

    private void startQRCodeScannerActivity() {
        Intent intent = new Intent(this, QRCodeDetailsActivity.class);
        startActivityForResult(intent, REQUEST_CODE_SCAN_QR_CODE);
    }
    private boolean checkStoragePermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }
    private String searchResultsToString(List<ItensVistorias> searchResults) {
        Gson gson = new Gson();
        return gson.toJson(searchResults);
    }

    private Bitmap generateQRCode(String data) {
        data = data.replace("\\u003d", "=").replace("\\u0026", "&");
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        try {
            BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, 200, 200);
            Bitmap bitmap = Bitmap.createBitmap(200, 200, Bitmap.Config.RGB_565);
            for (int x = 0; x < 200; x++) {
                for (int y = 0; y < 200; y++) {
                    bitmap.setPixel(x, y, bitMatrix.get(x, y) ? Color.BLACK : Color.WHITE);
                }
            }
            Log.d("QR", "QR Code data: " + data);

            return bitmap;
        } catch (WriterException e) {
            e.printStackTrace();
        }
        return null;
    }



    private void showQRCodeDialog(Bitmap qrCodeBitmap) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_qr_code, null);
        builder.setView(dialogView);

        ImageView imageViewQRCode = dialogView.findViewById(R.id.imageView_qr_code);
        Button buttonSaveQRCode = dialogView.findViewById(R.id.button_save_qr_code);
        Button buttonPrintQRCode = dialogView.findViewById(R.id.button_print_qr_code);

        imageViewQRCode.setImageBitmap(qrCodeBitmap);

        final AlertDialog qrCodeDialog = builder.create();

        buttonSaveQRCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Verifique a permissão de armazenamento
                if (ContextCompat.checkSelfPermission(Relatorios.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    // Salve o QR Code no dispositivo
                    String filePath = saveQRCodeToStorage(qrCodeBitmap);

                    // Compartilhe o QR Code
                    shareQRCode(filePath);

                    // Feche o diálogo
                    qrCodeDialog.dismiss();
                } else {
                    // Solicite a permissão de armazenamento
                    ActivityCompat.requestPermissions(Relatorios.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                }
            }
        });

        buttonPrintQRCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Implemente a função para imprimir o QR Code
                printQRCode(qrCodeBitmap);

                // Feche o diálogo
                qrCodeDialog.dismiss();
            }
        });

        qrCodeDialog.show();
    }
    private void printQRCode(Bitmap qrCodeBitmap) {
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);

        PrintDocumentAdapter printDocumentAdapter = new PrintDocumentAdapter() {
            @Override
            public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes, CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle extras) {
                if (cancellationSignal.isCanceled()) {
                    callback.onLayoutCancelled();
                } else {
                    PrintDocumentInfo.Builder builder = new PrintDocumentInfo
                            .Builder("qr_code_print_job")
                            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                            .setPageCount(1);

                    PrintDocumentInfo info = builder.build();
                    callback.onLayoutFinished(info, true);
                }
            }

            @Override
            public void onWrite(PageRange[] pages, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback callback) {
                PdfDocument document = new PdfDocument();
                PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(qrCodeBitmap.getWidth(), qrCodeBitmap.getHeight(), 1).create();
                PdfDocument.Page page = document.startPage(pageInfo);

                Canvas canvas = page.getCanvas();
                Paint paint = new Paint();
                canvas.drawBitmap(qrCodeBitmap, 0, 0, paint);

                document.finishPage(page);

                try {
                    OutputStream out = new FileOutputStream(destination.getFileDescriptor());
                    document.writeTo(out);
                    callback.onWriteFinished(new PageRange[]{new PageRange(0, 0)});
                } catch (IOException e) {
                    e.printStackTrace();
                    callback.onWriteFailed(e.getMessage());
                } finally {
                    document.close();
                }
            }
        };

        String jobName = getString(R.string.app_name) + " Document";
        printManager.print(jobName, printDocumentAdapter, null);
    }

    public interface SearchCallback {
        void onSearchCompleted(List<ItensVistorias> itemList);
    }

    private void requestStoragePermission() {
        Log.d("STORAGE_PERMISSION", "Solicitando permissão de armazenamento externo");
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                REQUEST_WRITE_STORAGE);
    }

    public void searchByCategory(String category, SearchCallback callback) {
        ItensVistorias.recuperarAnunciosPorCategoria(category).addOnCompleteListener(new OnCompleteListener<List<ItensVistorias>>() {
            @Override
            public void onComplete(@NonNull Task<List<ItensVistorias>> task) {
                if (task.isSuccessful()) {
                    List<ItensVistorias> resultList = task.getResult();
                    anuncios.clear();
                    anuncios.addAll(resultList);
                    adapterAnuncios.notifyDataSetChanged();
                    callback.onSearchCompleted(resultList);
                } else {
                    Log.e("SEARCH_ERROR", "Erro na busca: " + task.getException().getMessage());
                }
            }
        });
    }

    public void searchByLicensePlate(String licensePlate, SearchCallback callback) {
        ItensVistorias.recuperarAnunciosPorPlaca(licensePlate).addOnCompleteListener(new OnCompleteListener<List<ItensVistorias>>() {
            @Override
            public void onComplete(@NonNull Task<List<ItensVistorias>> task) {
                if (task.isSuccessful()) {
                    List<ItensVistorias> resultList = task.getResult();
                    anuncios.clear();
                    anuncios.addAll(resultList);
                    adapterAnuncios.notifyDataSetChanged();
                    callback.onSearchCompleted(resultList);
                } else {
                    Log.e("SEARCH_ERROR", "Erro na busca: " + task.getException().getMessage());
                    Toast.makeText(Relatorios.this, "Erro na busca: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

        public List<ItensVistorias> filterByDate(List<ItensVistorias> anuncios, String startDate, String endDate) {
        List<ItensVistorias> filteredAnuncios = new ArrayList<>();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());

        try {
            Date start = dateFormat.parse(startDate);
            Date end = dateFormat.parse(endDate);

            for (ItensVistorias anuncio : anuncios) {
                Date anuncioDate = dateFormat.parse(anuncio.getData());

                if ((anuncioDate.equals(start) || anuncioDate.after(start)) && (anuncioDate.equals(end) || anuncioDate.before(end))) {
                    filteredAnuncios.add(anuncio);
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao filtrar por data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        return filteredAnuncios;
    }

    private void createFile() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, "");
        startActivityForResult(intent, CREATE_FILE_REQUEST);
    }

    private void createPdf(List<ItensVistorias> vistorias) {
        if (vistorias.isEmpty()) {
            Toast.makeText(this, "Não há dados para gerar o PDF!", Toast.LENGTH_SHORT).show();
            return;
        }
        Log.d("PDF", "Número de vistorias filtradas: " + vistorias.size());
        createFile();
    }


    private void checkWriteStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            Log.d("PDF", "Permissão de escrita em armazenamento externo concedida!");
            createPdf(anuncios);
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CREATE_FILE_REQUEST && resultCode == RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();

                // Exemplo de datas de início e término para filtrar os anúncios
                String startDate = "01/01/2023";
                String endDate = "31/12/2023";

                List<ItensVistorias> filteredAnuncios = filterByDate(anuncios, startDate, endDate);
                savePdfToFile(uri, filteredAnuncios); // Adicione os anúncios filtrados como parâmetro
            }
        } else if (requestCode == REQUEST_CODE_SCAN_QR_CODE && resultCode == Activity.RESULT_OK && data != null) {
            String qrCodeData = data.getStringExtra("qr_code_data");

            // Adicione o log aqui
            Log.d("QRCodeData", "Received QR Code data: " + qrCodeData);

            // Agora você pode passar o qrCodeData para a sua QRCodeDetailsActivity
            Intent intent = new Intent(this, QRCodeDetailsActivity.class);
            intent.putExtra("qr_code_data", qrCodeData);
            startActivity(intent);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("PDF", "Permissão de escrita em armazenamento externo concedida após solicitação do usuário!");
                createPdf(anuncios);
            } else {
                Log.d("STORAGE_PERMISSION", "Permissão de armazenamento externo negada pelo usuário");
                Toast.makeText(this, "A permissão de armazenamento externo é necessária para gerar o relatório", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void savePdfToFile(Uri uri, List<ItensVistorias> filteredAnuncios){
        Log.d("PDF_SAVE", "PdfDocument criado e iniciado");
        try {

            // Inicializar um PdfDocument
            PdfDocument document = new PdfDocument();

            // Medidas em pontos (1 polegada = 72 pontos)
            int pageWidth = 792;
            int pageHeight = 1122;

            // Adicionar uma nova página ao documento
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();

            // Adicionar o conteúdo do PDF aqui usando o objeto Canvas
            Paint paint = new Paint();
            Log.d("PDF_SAVE", "Conteúdo do PDF adicionado");
            // Adicionando título e subtítulo
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            paint.setTextSize(20);
            paint.setColor(Color.BLACK);
            canvas.drawText("Relatório de Vistorias Concluídas", 50, 100, paint);

            paint.setTextSize(16);
            canvas.drawText("Detalhes da Vistoria", 50, 150, paint);

            // Desenhar a tabela
            int startY = 200;
            int startX = 50;
            int cellWidth = 100;

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2);

            // Desenhar linhas horizontais
            for (int i = 0; i < anuncios.size() + 2; i++) {
                canvas.drawLine(startX, startY + i * 50, startX + 6 * cellWidth, startY + i * 50, paint);
            }

            // Desenhar linhas verticais
            for (int i = 0; i < 7; i++) {
                canvas.drawLine(startX + i * cellWidth, startY, startX + i * cellWidth, startY + (anuncios.size() + 1) * 50, paint);
            }

            // Adicionar cabeçalho da tabela
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(12);

            canvas.drawText("Item", startX + 10, startY + 30, paint);
            canvas.drawText("Nº Patrimônio", startX + cellWidth + 10, startY + 30, paint);
            canvas.drawText("Observações", startX + 2 * cellWidth + 10, startY + 30, paint);
            canvas.drawText("Vistoriador", startX + 3 * cellWidth + 10, startY + 30, paint);
            canvas.drawText("Data da Vistoria", startX + 4 * cellWidth + 10, startY + 30, paint);
            canvas.drawText("Localização", startX + 5 * cellWidth + 10, startY + 30, paint);

            // Adicionar dados à tabela
            int rowIndex = 1;
            for (ItensVistorias vistoria : anuncios) {
                canvas.drawText(vistoria.getNomeItem(), startX + 10, startY + 30 + rowIndex * 50, paint);
                canvas.drawText(vistoria.getPlaca(), startX + cellWidth + 10, startY + 30 + rowIndex * 50, paint);
                canvas.drawText(vistoria.getOutrasInformacoes(), startX + 2 * cellWidth + 10, startY + 30 + rowIndex * 50, paint);
                canvas.drawText(vistoria.getNomePerfilU(), startX + 3 * cellWidth + 10, startY + 30 + rowIndex * 50, paint);
                canvas.drawText(vistoria.getData(), startX + 4 * cellWidth + 10, startY + 30 + rowIndex * 50, paint);
                canvas.drawText(vistoria.getLocalizacao(), startX + 5 * cellWidth + 10, startY + 30 + rowIndex * 50, paint);
                rowIndex++;
            }
            // Finalizar a página
            document.finishPage(page);

            // Salvar o documento no arquivo Uri fornecido
            ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "w");
            Log.d("PDF_SAVE", "Tentativa de salvar o documento no arquivo Uri");
            if (pfd != null) {
                Log.d("PDF_SAVE", "ParcelFileDescriptor obtido com sucesso");
                try (FileOutputStream fos = new FileOutputStream(pfd.getFileDescriptor())) {
                    Log.d("PDF_SAVE", "Tentativa de escrever o documento no arquivo");
                    document.writeTo(fos);
                    Toast.makeText(this, "PDF criado com sucesso!", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Log.e("PDF_SAVE", "Erro ao escrever o documento no arquivo: " + e.getMessage());
                    e.printStackTrace();
                    Toast.makeText(this, "Erro ao criar o PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                } finally {
                    document.close();
                    pfd.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            Log.e("PDF_SAVE", "Erro ao criar o PDF: " + e.getMessage());
            Toast.makeText(this, "Erro ao criar o PDF: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    private String saveQRCodeToStorage(Bitmap qrCodeBitmap) {
        try {
            File directory = new File(getExternalFilesDir(null), "QRCode");
            if (!directory.exists()) {
                if (!directory.mkdirs()) {
                    throw new IOException("Failed to create directory");
                }
            }

            File file = new File(directory, "QRCode_" + System.currentTimeMillis() + ".png");
            FileOutputStream outputStream = new FileOutputStream(file);
            qrCodeBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream);
            outputStream.flush();
            outputStream.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    private void shareQRCode(String filePath) {
        File fileToShare = new File(filePath);
        Uri contentUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", fileToShare);

        // Compartilhar o arquivo usando um Intent
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/png");
        shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); // Adicione esta flag
        startActivity(Intent.createChooser(shareIntent, "Compartilhar QR Code via"));
    }


    private String formatReportData(List<ItensVistorias> anuncios) {
        StringBuilder dataBuilder = new StringBuilder();

        for (ItensVistorias anuncio : anuncios) {
            dataBuilder.append("Nome do inspetor: ").append(anuncio.getNomePerfilU()).append("\n");
            dataBuilder.append("Data: ").append(anuncio.getData()).append("\n");
            // Adicione outras informações do relatório aqui.
            dataBuilder.append("\n");
        }

        return dataBuilder.toString();
    }


}







